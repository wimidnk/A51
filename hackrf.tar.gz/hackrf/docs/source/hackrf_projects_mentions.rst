================================================
HackRF Community Projects and Mentions
================================================

Have you done something cool with HackRF or mentioned HackRF in one of your presentations? Let us know and we might post a link here!

* `HackRF vs. Tesla Model S <https://www.youtube.com/watch?v=575TcQJJWok>`__ (Sam Edwards)
* `Jawbreaker/VFD spectrum analyzer <http://www.sharebrained.com/2013/05/21/maker-faire-radio-spectrum-analyzer/>`__ (Jared Boone)
* `LEGO car <http://ossmann.blogspot.com/2013/06/hackrf-lego-car.html>`__ (Michael Ossmann)
* `wireless microphones <http://www.sharebrained.com/2013/06/15/wireless-microphones-and-hackrf/>`__ (Jared Boone)
* `Tesla Charging Port Opener <https://github.com/rgerganov/tesla-opener>`__ (Radoslav Gerganov)
* `Hacking my smart tooth brush <https://kuenzi.dev/toothbrush/>`__ (Cyrill Künzi)



Retired Projects
~~~~~~~~~~~~~~~~

* Automotive Remote Keyless Entry Systems (Mike Kershaw)
* Decoding Pocsag Pagers With The HackRF (BinaryRF)
* Sniffing GSM with HackRF (BinaryRF)