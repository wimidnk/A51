================================================
Firmware Development Setup
================================================

Firmware build instructions are included in the repository under firmware/README:

`https://github.com/greatscottgadgets/hackrf/blob/master/firmware/README <https://github.com/greatscottgadgets/hackrf/blob/master/firmware/README>`__
