==========
Connectors
==========

The connectors on HackRF One are SMA. 

**Note:** SMA connectors and RP-SMA connectors are visually very similar. If you connect an RP-SMA antenna to HackRF One, it will seem to connect snugly but won't function at all because neither the male nor female side has a center pin. RP-SMA connectors are most common on 2.4 GHz antennas and are popular on Wi-Fi equipment. Adapters are available.
